"""查询流年十二宫、禄羊陀与具名四化，并按初一或立春日期确定纪年。

纯纪年查询不加载历法适配；日期计算及日期结果构造按需导入。
禄羊陀出处见知识条目entry.liunian.lucun-yangtuo。
"""

from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from enum import StrEnum
from typing import TYPE_CHECKING, Final, TypeAlias

from ziwei.ganzhi import Dizhi, Ganzhi, Tiangan, year_ganzhi
from ziwei.palaces import PalaceName, palace_dizhi
from ziwei.sihua import SihuaVariant, sihua_for_stem
from ziwei.stars import Star, lucun_yangtuo_dizhi

if TYPE_CHECKING:
  from ziwei.calendar import LunarAlgorithm

LIUNIAN_MINGGONG_RULE_ID: Final = "variant.liunian.year-branch"
"""目标流年地支落同支宫的规则标识。"""
LIUNIAN_STARS_RULE_ID: Final = "variant.liunian.lucun-yangtuo"
"""按流年干安禄存、擎羊与陀罗的规则标识。"""
LIUNIAN_STARS_DEFINITION: Final = "以已确定流年的年干查禄存，禄存顺一宫为流羊、逆一宫为流陀。"
"""年度禄羊陀的安置方法。"""
LIUNIAN_PALACES_RULE_ID: Final = "variant.liunian.twelve-palaces"
"""太岁宫起年度十二宫的规则标识。"""
LIUNIAN_PALACES_DEFINITION: Final = "以目标纪年的太岁年支为流年命宫，按人事十二宫次序逆布。"
"""年度十二宫的定位方法。"""
LIUNIAN_SIHUA_RULE_ID: Final = "variant.liunian.sihua-wangtingzhi-lecture"
"""讲义表用于年度四化的规则标识，与原完整表标识分开。"""
LIUNIAN_SIHUA_DEFINITION: Final = (
  "按目标流年干读取王亭之讲义转录完整表，依次取得年度禄、权、科、忌。"
)
"""具名年度四化的查法。"""


@dataclass(frozen=True, slots=True)
class LiunianStars:
  """已确定纪年的流禄、流羊、流陀；三位置由纪年派生。"""

  ganzhi_year: int
  lucun: Dizhi = field(init=False)
  qingyang: Dizhi = field(init=False)
  tuoluo: Dizhi = field(init=False)

  def __post_init__(self) -> None:
    positions = lucun_yangtuo_dizhi(self.year_ganzhi.tiangan)
    for name, position in zip(("lucun", "qingyang", "tuoluo"), positions, strict=True):
      object.__setattr__(self, name, position)

  @property
  def year_ganzhi(self) -> Ganzhi:
    """目标纪年的干支。"""
    return year_ganzhi(self.ganzhi_year)

  @property
  def rule_id(self) -> str:
    """年度禄羊陀实际使用的规则标识。"""
    return LIUNIAN_STARS_RULE_ID

  @property
  def 纪年(self) -> int:
    return self.ganzhi_year

  @property
  def 禄存(self) -> Dizhi:
    return self.lucun

  @property
  def 擎羊(self) -> Dizhi:
    return self.qingyang

  @property
  def 陀罗(self) -> Dizhi:
    return self.tuoluo

  @property
  def 年干支(self) -> Ganzhi:
    return self.year_ganzhi


def liunian_stars(ganzhi_year: int) -> LiunianStars:
  """查询已确定纪年1至9999的年度禄羊陀，拒绝bool。"""
  return LiunianStars(ganzhi_year)


class LiunianBoundary(StrEnum):
  """流年日期查询的年界选项。"""

  LUNAR_NEW_YEAR = "正月初一日期"
  LICHUN_DATE = "立春日期"
  正月初一日期 = LUNAR_NEW_YEAR
  立春日期 = LICHUN_DATE

  @property
  def rule_id(self) -> str:
    """所选日期年界的规则标识。"""
    return {
      LiunianBoundary.LUNAR_NEW_YEAR: "variant.liunian.lunar-new-year",
      LiunianBoundary.LICHUN_DATE: "variant.liunian.lichun-date",
    }[self]


def liunian_minggong(ganzhi_year: int) -> Dizhi:
  """已确定纪年1至9999的流年命宫地支。"""
  return year_ganzhi(ganzhi_year).dizhi


def liunian_palace_dizhi(ganzhi_year: int, name: PalaceName) -> Dizhi:
  """从已确定纪年的太岁命宫逆排，查询指定年度宫名的地支。"""
  return palace_dizhi(liunian_minggong(ganzhi_year), name)


@dataclass(frozen=True, slots=True)
class LiunianSihua:
  """已确定纪年的具名年度四化，四星由目标年干和显式选择的表派生。"""

  ganzhi_year: int
  variant: SihuaVariant = field(kw_only=True)
  lu: Star = field(init=False)
  quan: Star = field(init=False)
  ke: Star = field(init=False)
  ji: Star = field(init=False)

  def __post_init__(self) -> None:
    stem = self.year_tiangan
    if not isinstance(self.variant, SihuaVariant):
      raise TypeError("年度四化变体须为 SihuaVariant 成员")
    if self.variant is not SihuaVariant.WANGTINGZHI_LECTURE:
      raise ValueError("此四化表尚不支持年度查询")
    result = sihua_for_stem(stem, self.variant)
    for name, star in zip(
      ("lu", "quan", "ke", "ji"), (result.lu, result.quan, result.ke, result.ji), strict=True
    ):
      object.__setattr__(self, name, star)

  @property
  def year_ganzhi(self) -> Ganzhi:
    return year_ganzhi(self.ganzhi_year)

  @property
  def year_tiangan(self) -> Tiangan:
    return self.year_ganzhi.tiangan

  @property
  def rule_id(self) -> str:
    """年度查法的知识标识。"""
    return LIUNIAN_SIHUA_RULE_ID

  @property
  def table_id(self) -> str:
    """所用完整四化表的知识标识。"""
    return self.variant.rule_id

  @property
  def 纪年(self) -> int:
    return self.ganzhi_year

  @property
  def 年干支(self) -> Ganzhi:
    return self.year_ganzhi

  @property
  def 年干(self) -> Tiangan:
    return self.year_tiangan

  @property
  def 变体(self) -> SihuaVariant:
    return self.variant

  @property
  def 化禄(self) -> Star:
    return self.lu

  @property
  def 化权(self) -> Star:
    return self.quan

  @property
  def 化科(self) -> Star:
    return self.ke

  @property
  def 化忌(self) -> Star:
    return self.ji


def liunian_sihua(ganzhi_year: int, *, variant: SihuaVariant) -> LiunianSihua:
  """查询1至9999纪年的年度四化；须显式选表，不支持的年度变体抛ValueError。"""
  return LiunianSihua(ganzhi_year, variant=variant)


def _checked_algorithm(
  boundary: LiunianBoundary, algorithm: LunarAlgorithm | None
) -> LunarAlgorithm | None:
  from ziwei.calendar import LunarAlgorithm

  if not isinstance(boundary, LiunianBoundary):
    raise TypeError("流年年界须为 LiunianBoundary 成员")
  if boundary is LiunianBoundary.LUNAR_NEW_YEAR:
    if not isinstance(algorithm, LunarAlgorithm):
      raise TypeError("正月初一日期须显式指定 LunarAlgorithm")
    return algorithm
  if boundary is LiunianBoundary.LICHUN_DATE:
    if algorithm is not None:
      raise TypeError("立春日期不使用农历算法")
    return None
  raise ValueError("尚未实现流年年界")


def _supported_year_range(algorithm: LunarAlgorithm | None) -> tuple[int, int]:
  """完整纪年区间需要下一年的年界，因此最后一个年界年份减一。"""
  from ziwei.calendar import LICHUN_DATE_YEAR_RANGE, supported_lunar_year_range

  if algorithm is not None:
    return supported_lunar_year_range(algorithm)
  first, final_boundary = LICHUN_DATE_YEAR_RANGE
  return first, final_boundary - 1


@dataclass(frozen=True, slots=True, kw_only=True)
class LiunianYear:
  """按日换年的干支年区间，start含、end不含；构造只校验字段关系，不重算历法。"""

  ganzhi_year: int
  boundary: LiunianBoundary
  start: datetime.date
  end: datetime.date
  lunar_algorithm: LunarAlgorithm | None
  celestial_version: str
  supported_year_range: tuple[int, int] = field(init=False)

  def __post_init__(self) -> None:
    year_ganzhi(self.ganzhi_year)
    algorithm = _checked_algorithm(self.boundary, self.lunar_algorithm)
    supported = _supported_year_range(algorithm)
    if not supported[0] <= self.ganzhi_year <= supported[1]:
      raise ValueError("干支年超出所选流年年界支持范围")
    if type(self.start) is not datetime.date or type(self.end) is not datetime.date:
      raise TypeError("流年区间端点须为 date，不接受 datetime")
    if (
      self.start >= self.end
      or self.start.year != self.ganzhi_year
      or self.end.year != self.ganzhi_year + 1
    ):
      raise ValueError("流年区间须始于所归纪年并终于下一纪年")
    if not isinstance(self.celestial_version, str):
      raise TypeError("celestial版本须为字符串")
    if not self.celestial_version.strip():
      raise ValueError("celestial版本不可为空")
    object.__setattr__(self, "supported_year_range", tuple(supported))

  @property
  def year_ganzhi(self) -> Ganzhi:
    """所归纪年的干支。"""
    return year_ganzhi(self.ganzhi_year)

  @property
  def minggong(self) -> Dizhi:
    """流年命宫地支。"""
    return liunian_minggong(self.ganzhi_year)

  @property
  def rule_id(self) -> str:
    """流年命宫定位的规则标识。"""
    return LIUNIAN_MINGGONG_RULE_ID

  @property
  def date_basis(self) -> str:
    """区间端点的日期基准；农历标签的具体基准见lunar_algorithm。"""
    if self.boundary is LiunianBoundary.LICHUN_DATE:
      return "UTC+08"
    return "所选农历算法日期标签"

  @property
  def 纪年(self) -> int:
    return self.ganzhi_year

  @property
  def 年界(self) -> LiunianBoundary:
    return self.boundary

  @property
  def 起始日期(self) -> datetime.date:
    return self.start

  @property
  def 终止日期(self) -> datetime.date:
    return self.end

  @property
  def 年干支(self) -> Ganzhi:
    return self.year_ganzhi

  @property
  def 命宫(self) -> Dizhi:
    return self.minggong


def liunian_on_date(
  day: datetime.date,
  *,
  boundary: LiunianBoundary,
  lunar_algorithm: LunarAlgorithm | None = None,
) -> LiunianYear:
  """按显式年界查询日期所归的干支年及完整区间。

  初一路径必须指定农历算法，输入为该算法基准的公历日期标签；立春路径只收UTC+08日期，
  不接受农历算法。两个路径都拒绝datetime。范围外抛ValueError，原生历法故障原样传播。
  """
  from ziwei.calendar import (
    celestial_version,
    gregorian_to_lunar,
    lichun_date,
    lunar_year_info,
  )

  if type(day) is not datetime.date:
    raise TypeError("流年日期须为 date，不接受 datetime")
  algorithm = _checked_algorithm(boundary, lunar_algorithm)
  if algorithm is not None:
    year, _, _, _ = gregorian_to_lunar(algorithm, day)
    start, _, lengths = lunar_year_info(algorithm, year)
    end = start + datetime.timedelta(days=sum(lengths))
  else:
    first, last = _supported_year_range(algorithm)
    if not first <= day.year <= last + 1:
      raise ValueError("日期超出立春流年支持范围")
    current_boundary = lichun_date(day.year)
    year = day.year if day >= current_boundary else day.year - 1
    if not first <= year <= last:
      raise ValueError("日期超出立春流年支持范围")
    start = current_boundary if year == day.year else lichun_date(year)
    end = lichun_date(year + 1) if year == day.year else current_boundary
  return LiunianYear(
    ganzhi_year=year,
    boundary=boundary,
    start=start,
    end=end,
    lunar_algorithm=algorithm,
    celestial_version=celestial_version(),
  )


流年星曜: TypeAlias = LiunianStars
流年年界: TypeAlias = LiunianBoundary
流年区间: TypeAlias = LiunianYear
流年四化: TypeAlias = LiunianSihua
